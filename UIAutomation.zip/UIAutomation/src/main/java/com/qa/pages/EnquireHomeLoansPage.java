package com.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.util.TestBase;

public class EnquireHomeLoansPage extends TestBase{
	
	EnquireHomeLoansPage eHLP;
	//page factory: Object Repository
	
	//Customer assistance directory
	@FindBy(xpath="//h1[contains(text(),'Customer assistance directory')]")
	WebElement custAssistDirectory;
	
	
	//Initializing page objects
		public EnquireHomeLoansPage() {
			PageFactory.initElements(driver, this);
		}
		
		public String verifyEnquireHomeLoansPageTitle() {
			return driver.getTitle();
		}
		
		public HomeloanFormsPage selectHomeandClickNext() {
			eHLP= new EnquireHomeLoansPage();
			eHLP.selectHomeLoansOption();
			eHLP.clickOnNext();	
			return new HomeloanFormsPage();
		}
		
	//Returns webelement shadow root element method
		public WebElement expandRootElement(WebElement element) {
			WebElement ele = (WebElement) ((JavascriptExecutor) driver)
					.executeScript("return arguments[0].shadowRoot", element);
			return ele;
		}
		
		//Shadow DOM Root element identification	
		public void selectHomeLoansOption() {
			
			WebElement root1 = driver.findElement(By.xpath("//div[@id='contact-form-shadow-root']"));
			WebElement shadowRoot = expandRootElement(root1);
			
			WebElement reqdEletoClick = shadowRoot.findElement(By.xpath("//div[@id='myRadioButton-0']"));
			//return reqdEletoClick;
			reqdEletoClick.click();
		}
		
		public void clickOnNext() {
			
			WebElement root1 = driver.findElement(By.xpath("//div[@id='contact-form-shadow-root']"));
			WebElement shadowRoot = expandRootElement(root1);
			
			WebElement reqdButtontoClick = shadowRoot.findElement(By.xpath("//span[contains(text(),'Next')]"));
			//return reqdEletoClick;
			reqdButtontoClick.click();
		}
		
	

}
