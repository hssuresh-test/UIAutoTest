package com.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.util.TestBase;

public class HomeloanFormsPage extends TestBase {
	
	
	//page factory: Object Repository
		
		//validation of Call Center call back form
		@FindBy(xpath="//h1[@id='Page1']")
		WebElement callBackForm;
		
		
		//consider option as yes or no
		@FindBy(xpath="//span[contains(text(),'No')]")
		WebElement optionYesNo;
		
		
		//enter firstName
		@FindBy(xpath="//input[@id='field-page-Page1-aboutYou-firstName']")
		WebElement enterFirstName;
		
		
		//enter lastName
		@FindBy(xpath="//input[@id='field-page-Page1-aboutYou-lastName']")
		WebElement enterLastName;
		
		
		//select state
		@FindBy(xpath="//div[@class='css-10kdyoj-control react-select__control']")
		WebElement selectState;
		
		
		//enter Phone Number
		@FindBy(xpath="//input[@id='field-page-Page1-aboutYou-phoneNumber']")
		WebElement phoneNumber;
		
		
		//enter email id 
		@FindBy(xpath="//input[@id='field-page-Page1-aboutYou-email']")
		WebElement emailId;
		
		
		//click on submit button
		@FindBy(xpath="//span[contains(text(),'Submit')]")
		WebElement submitButton;
		
		//Initializing page objects
		public HomeloanFormsPage() {
			PageFactory.initElements(driver, this);
		}

		public String verifyHomeLoanFormsPageTitle() {
			return driver.getTitle();
		}
		
		public boolean verifyHomeLoanFormsPageConfirm() {
			return callBackForm.isDisplayed();
		}
		
		public ConfirmPage enterFormDetailsAndSubmit(String firstName, String lastName, String state, String phoneNo, String email) {
			
			optionYesNo.click();
			enterFirstName.sendKeys(firstName);
			enterLastName.sendKeys(lastName);
			
			Select drpState= new Select(selectState);
			drpState.selectByVisibleText(state);
			
			phoneNumber.sendKeys(phoneNo);
			emailId.sendKeys(email);
			
			submitButton.click();		
			return new ConfirmPage();
		}
}
